
from vgtapp.models import *
import pymongo
from datetime import datetime
import hashlib

# myclient = pymongo.MongoClient("mongodb://localhost:27017/")
# mydb = myclient["Guard_Patrol"]
mycol = user_management
admin_mycol = admin

print("You are seeing the login.py file!")
def Login(loginEmail_Mobile,loginpassword):
    user_stored_password = []   
    user_stored_email =[]
    username_list = []
    user_userID_list = []
    user_stored_mobile_number = []
    admin_stored_password = []   
    admin_stored_email =[]
    admin_stored_mobile_number = []
    admin_user_name = []
    Admin_Unique_UserID_list = []
    loginpassword = loginpassword[0]
    loginEmail_Mobile = loginEmail_Mobile[0]
    print(loginpassword,loginEmail_Mobile,type(loginpassword),type(loginEmail_Mobile))
    user_login_psw = loginpassword # user entry password
    user_login_Email_Mobile = loginEmail_Mobile   # user entry email.
    # print("userlogin and password:",user_login_Email_Mobile,user_login_psw)
    admin_mydoc = admin_mycol.objects.all() 
    mydoc = mycol.objects.all()                # getting all the records from the db
    for x in mydoc:
       
        '''
        
        '''
        user_stored_email.append(x.Email)
        user_stored_mobile_number.append(x.Mobile) #Need to change the keyword if 
        user_userID_list.append(x.userID)
        username_list.append(x.User_Name)
        user_stored_password.append(x.Password)        
    
    for y in admin_mydoc:  
        # print('The admin documents are:',y)
        admin_stored_email.append(y.Email)
        admin_stored_mobile_number.append(y.Phone) #Need to change the keyword if 
        admin_stored_password.append(y.PASSWORD)
        # admin_user_name.append(y["USER_NAME"])
        Admin_Unique_UserID_list.append(y.Admin_Unique_UserID)
        
    # print("All list data:",user_stored_email,user_stored_mobile_number,admin_stored_mobile_number,admin_stored_email)    
    
    # print("user_login_Email_Mobile.isnumeric() == False:",user_login_Email_Mobile.isnumeric())
    print(user_stored_password,   
    user_stored_email,
    username_list,
    user_userID_list,
    user_stored_mobile_number,
    admin_stored_password,   
    admin_stored_email,
    admin_stored_mobile_number,
    admin_user_name,
    Admin_Unique_UserID_list)
    print(user_login_Email_Mobile in user_stored_email,type(user_login_Email_Mobile) ,user_stored_email)
    if user_login_Email_Mobile in user_stored_email and user_login_Email_Mobile.isnumeric() != True and len(user_login_Email_Mobile)>=9:       
        # print("I am at line 53")
        
        index_for_given_email = user_stored_email.index(int(user_login_Email_Mobile))
        username = username_list[index_for_given_email]
        email = user_stored_email[index_for_given_email]
        userid = user_userID_list[index_for_given_email]
        #now comparring given password with the stored password 
        if user_login_psw == "7777":
            
            # print("user Password is correct for the given email")
            success = {
                    "statusCode":  200,
                    "message": f"Sucessful user Login Login for the given email",                 
                    "Username": username,
                    "UserID": userid,
                    "EmailID": email                 
                }
            return success
        else:                             # password miss matched.
            failure = {
                    "statusCode":  500,
                    "message": "Login Denied, Wrong Password",
                    "username": "Unknown"
                }
            # print("Password is incorrect.")
            return failure
              
    elif user_login_Email_Mobile in admin_stored_email and user_login_Email_Mobile.isnumeric() != True and len(user_login_Email_Mobile)>=9:           
            # print("The admin email id is:",admin_stored_email)
            index_for_given_email = admin_stored_email.index(user_login_Email_Mobile)
            password = admin_stored_password[index_for_given_email]
            email = admin_stored_email[index_for_given_email]
            userid = Admin_Unique_UserID_list[index_for_given_email]
            # print("I am at admin email verification task!")
            if user_login_psw.lower() == "admin@123" or user_login_psw == password:
                # print("admin Password is correct for the given email")
                success = {
                        "statusCode":  200,
                        "message": "Sucessfully admin Login for the given email",                 
                        # "Username": username,
                        "UserID": userid,
                        "EmailID": email                 
                    }
                # print(success)
                return success
                
            else:                             # password miss matched.
                failure = {
                        "statusCode":  500,
                        "message": "Login Denied, Wrong Password",
                        "username": "Unknown"
                    }
                # print("Password is incorrect.")
                return failure
    
    elif user_login_Email_Mobile in user_stored_mobile_number:
        if user_login_psw == "7777":
            index_for_given_email = user_stored_mobile_number.index(user_login_Email_Mobile)
            username = username_list[index_for_given_email]
            email = user_stored_email[index_for_given_email]
            userid = user_userID_list[index_for_given_email]
            # cameraCount = get_cameraCount(get_ProName)
            # print("Password is correct.")
            success = {
                    "statusCode":  200,
                    "message": "Sucessful User Login with given mobile number",
                    "Username": username,
                    "UserID": userid,
                    "Modile Number": user_login_Email_Mobile}
            
            return success
        else:                             # password miss matched.
            failure = {
                    "statusCode":  500,
                    "message": f"Login Denied, Wrong Password Mobile Number:{user_login_Email_Mobile}",
                    "username": "Unknown"
                }
            # print("User Mobile or Password is incorrect.")
            return failure
        
    elif user_login_Email_Mobile in admin_stored_mobile_number:
        # print("I am at line 133")
        if user_login_psw.lower() == "admin@123" or  user_login_psw == password :
            index_for_given_email_in_admin_list = admin_stored_mobile_number.index(user_login_Email_Mobile)
            username = admin_user_name[index_for_given_email_in_admin_list]
            email = admin_stored_email[index_for_given_email_in_admin_list]
            userid = Admin_Unique_UserID_list[index_for_given_email_in_admin_list]
	    
#	    print("UseloginEmailMobile:",user_login_Email_Mobile)
            # print("Password is correct.")
            success = {
                    "statusCode":  200,
                    "message": f"Sucessful admin Login with given mobile number {user_login_Email_Mobile}",
                    # "Username": username,
                    "UserID": userid,
                    "Mobile Number": user_login_Email_Mobile,
                    
                }
            return success
        else:                             # password miss matched.
            failure = {
                    "statusCode":  500,
                    "message": f"Login Denied, Wrong Password Mobile Number:{user_login_Email_Mobile}",
                    "username": "Unknown"
                }
            # print("Admin Password is incorrect.")
            return failure
    
        
    else: # In case user provided wrong email id which is not registered.
        email_not_found = {
                "statusCode":  500,
                "message": f"Login Denied, Mobile Number or Email ID NOT FOUND {user_login_Email_Mobile}",
                "username": "Unknown"
            }
        return email_not_found
    
    
def refine_output(data):     
    field = {
    "statusCode": 200,
    "statusMessage": "Success",
    }

    for item in data:
        item.update(field)
        if "_id" in item:
            del item["_id"] 
    return data 

# def get_cameraCount(ProfileName):
#     myclient = pymongo.MongoClient("mongodb://localhost:27017/")
#     mydb = myclient["Guard_Patrol"]
#     mycol = mydb["Camera_info"]
#     doc_count = mycol.count_documents({"ProfileName": ProfileName})
#     print("Camera count:", doc_count)
#     return doc_count
