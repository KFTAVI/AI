var vm = new Vue({
    el: "#onBoard",
    data: {
      ProfileName: "Pratik",
      CameraName: "",
      CameraType: "Test",
      CameraRTSP: "",
      Region: "",
      City: "",
      Location: "",
      TimeZone: "",
         },
   
        
    methods:{

  onChangeRegion: function (event) {
          this.RegionName = event.target.options[event.target.options.selectedIndex].value;
          this.RegionText = event.target.options[event.target.options.selectedIndex].text;
          $("#SelectRegion").val(this.Region);
      },
 
      onChangeCity: function (event) {
          this.CityName = event.target.options[event.target.options.selectedIndex].value;
          this.CityText = event.target.options[event.target.options.selectedIndex].text;
          $("#SelectCity").val(this.City);
      },
 
      onChangeLocation: function (event) {
          this.LocationName = event.target.options[event.target.options.selectedIndex].value;
          this.LocationText = event.target.options[event.target.options.selectedIndex].text;
          $("#SelectLocation").val(this.Location);
      },
 
      onChangeTimeZone: function (event) {
          this.TimezoneName = event.target.options[event.target.options.selectedIndex].value;
          this.TimezoneText = event.target.options[event.target.options.selectedIndex].text;
          $("#SelectTimeZone").val(this.TimeZone);
      },
  
         
            AddDeviceRTSP: function() {
          var userdata = {
            "ProfileName": this.ProfileName,
            "CameraName": this.CameraName,
            "CameraType": this.CameraType,
            "CameraRTSP": this.CameraRTSP,
            "Region": this.Region,
            "City": this.City,
            "Location": this.Location,
            "TimeZone": this.TimeZone
          };
         
        fetch("http://122.166.48.42:9093/CAMERA_Registration/", {
          method: "POST",
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(userdata),
        })
        .then(response => response.json())
        .then(data => {
          if (data.statusCode === 200) {
              alert('Device Added');
              this.clearfields();
  
          } else {
            alert('failed');
          }
        })
        .catch(error => {
          alert(error.message);
        });
      },
     
    },
  });
  

  