export default {
    data() {
      return {
        responseData: null,
        error: null,
      };
    },
    methods: {
      fetchData() {
        axios.get('http://122.166.48.42:9093/Vrtual_Guard_Tour_Registration/')
          .then((response) => {
            // Successful response
            this.responseData = response.data;
          })
          .catch((error) => {
            // Handle errors
            this.error = error;
          });
      },
    },
  };
  