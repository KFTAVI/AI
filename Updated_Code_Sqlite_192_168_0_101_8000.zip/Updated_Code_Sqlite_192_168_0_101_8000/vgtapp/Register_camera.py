import pymongo
from datetime import datetime
import urllib.parse
from vgtapp.models import Camera_info


stored_camera_name = []
stored_rtsp = []
#stored_camType = []
#store_pname = []
dt = []
cam_id = []
store_site = []
ip_address = ''

def init_data(admin):
    mydoc = Camera_info.objects.filter(Admin_unique_id = admin)
    stored_camera_name.clear()  
    stored_rtsp.clear()
    cam_id.clear()
    #store_pname.clear()
    
    for x in mydoc:
        # print("the docs are:",x)
        stored_camera_name.append(x.CameraName)  
        stored_rtsp.append(x.CameraRTSP)
        #store_pname.append(x['ProfileName'])
        cam_id.append(x.CameraID)

'''---8.11.2023, counting the number of cameras present for each site---'''
def site_camera_count(site_name,admin):
    input_site_name = site_name
    #count = 0
    
    '''
    for x in get_VGT_CameraInfo.find({"Site_Name": input_site_name},{"_id":0, "Site_Name":1}):
        store_site.append(x['Site_Name'])
    '''
    get_count = len([docs for docs in  Camera_info.objects.filter(Site_Name =  input_site_name,Admin_unique_id = admin)])
    # print(get_count)
    return get_count

       

def VGT_camera_register_info(data):
    
    print("I am at line 46")
    # from vgtapp.models import Camera_info
    '''--- added on 07.11.2023 ---'''
    st_name = data["Site_Name"]
    st_code = data["Site_Code"]
    '''---------------------------'''
    name = data["CameraName"]
    rtsp = data["CameraRTSP"]
    #pname = data["ProfileName"]
    cam_type = data["CameraType"].upper()
    re = data["Region"]
    ct = data["City"]
    loc = data["Location"]
    tz = data["TimeZone"]
    '''----12-12-2023-------------'''
    admin_id = data["Admin_id"]
    
    '''------------'''
    '''--get the ip out of rtsp'''
    # Parse the RTSP URL
    parsed_url = urllib.parse.urlparse(rtsp)
    # Extract the netloc, which contains the IP address and port
    input_string = parsed_url.netloc
    # Print the result
    # print('IP & Port:',input_string)
    # Split the string by '@' to get the part after '@'
    parts = input_string.split('@')
    if len(parts) == 2:
        # The IP address is in the second part after '@'
        ip_and_port = parts[1]

        # Split the remaining part by ':' to get the IP address
        ip_parts = ip_and_port.split(':')
        
        if len(ip_parts) == 1:
            # There is no port specified, so use the whole remaining part as the IP address
            ip_address = ip_parts[0]
            # print("IP Address:", ip_address)
        elif len(ip_parts) == 2:
            # The IP address is the first part, and the port is the second part
            ip_address, port = ip_parts
            # print("IP Address:", ip_address)
        else:
            print("Invalid format: Too many colons after '@'")
    else:
        print("Invalid format: Missing '@'")
    '''---------------------------'''
    
    row_count = len([docs for docs in  Camera_info.objects.filter(Site_Name =  st_name,Admin_unique_id = admin_id)])
    # print(row_count)
    if row_count != 0:
        for x in Camera_info.objects.filter(Site_Name = st_name,Admin_unique_id = admin_id):
            #p_name = x['ProfileName']
            #store_pname.append(p_name)

            c_rtsp = x.CameraRTSP
            stored_rtsp.append(c_rtsp)

            cn = x.CameraName
            stored_camera_name.append(cn)

            camID = x.CameraID
            cam_id.append(camID)
        # print("The max cam id:",cam_id,max(cam_id),type(cam_id),cam_id[0],type(cam_id[0]))
        max_value = max(cam_id)
        c_id = max_value + 1

        '''---Prevent duplicate entry, check on camera rtsp------'''
        #if rtsp in stored_rtsp and p_name in store_pname:
        if rtsp in stored_rtsp:
            index = stored_rtsp.index(rtsp)
            cname = stored_camera_name[index]
            #Pn = store_pname[index]
                
            show = {
                    "Status":500,
                    "message": "REGISTRATION DENIED!! CAMERA ALREADY REGISTERED",
                    #"Profile_Name": Pn,                    
                    "CAMERA_NAME": cname,
                    "RTSP": rtsp               
                }
            return show
        else:
            
            c_no = site_camera_count(st_name,admin_id)
            x = c_no + 1
            info = {
                    #"ProfileName": pname,
                    
                    "Site_Name": st_name,
                    "Site_Code": st_code,
                    "CameraName": name,
                    "CameraType": cam_type,
                    "CameraRTSP": rtsp,
                    "CameraIP": ip_address,
                    "Admin_id" : admin_id,
                    "CameraID": c_id,
                    "Region": re,
                    "City": ct,
                    "Location": loc,
                    "TimeZone": tz,
                    "is_active": 1,                   
                    "is_AutoRecording": True,  
                    "Site_Camera_Count": x,                  
                    "DateOfCameraRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p")
            }
    
        vgt_camerainfo = Camera_info.objects.create(            
            Site_Name= info["Site_Name"],
            Site_Code= info["Site_Code"],
            CameraName= info["CameraName"],
            CameraType= info["CameraType"],
            CameraRTSP= info["CameraRTSP"],
            CameraIP= info["CameraIP"],
            Admin_unique_id = info["Admin_id"],
            CameraID= info["CameraID"],
            Region= info["Region"],
            City= info["City"],
            Location= info["Location"],
            TimeZone= info["TimeZone"],
            is_active= 1,                   
            is_AutoRecording= True,  
            Site_Camera_Count= x,                  
            DateOfCameraRegistration= (datetime.today()).strftime("%b %d %Y, %I:%M %p")
            )
        vgt_camerainfo.save()
        field = {
            "statusCode": 200,
            "statusMessage": "SUCCESSFULLY REGISTERED!"
            }
        return field
    else:
        print("I am at the line 177 else condition")
        c_id = 1
        c_no = site_camera_count(st_name,admin_id)
        x = c_no + 1
        info = {
                    #"ProfileName": pname,
                    "Site_Name": st_name,
                    "Site_Code": st_code,
                    "CameraName": name,
                    "CameraType": cam_type,
                    "CameraRTSP": rtsp,
                    "CameraIP": ip_address,
                    "CameraID": c_id,
                    "Admin_id" : admin_id,
                    "Region": re,
                    "City": ct,
                    "Location": loc,
                    "TimeZone": tz,
                    "is_active": 1,                   
                    "is_AutoRecording": True,
                    "Site_Camera_Count": x,                    
                    "DateOfCameraRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p")
            }
            
        vgt_camerainfo = Camera_info.objects.create(            
            Site_Name= info["Site_Name"],
            Site_Code= info["Site_Code"],
            CameraName= info["CameraName"],
            CameraType= info["CameraType"],
            CameraRTSP= info["CameraRTSP"],
            CameraIP= info["CameraIP"],
            Admin_unique_id = info["Admin_id"],
            CameraID= info["CameraID"],
            Region= info["Region"],
            City= info["City"],
            Location= info["Location"],
            TimeZone= info["TimeZone"],
            is_active= 1,                   
            is_AutoRecording= True,  
            Site_Camera_Count= x,                  
            DateOfCameraRegistration= (datetime.today()).strftime("%b %d %Y, %I:%M %p")
            )
        vgt_camerainfo.save()
    field1 = {
            "statusCode": 200,
            "statusMessage": "SUCCESSFULLY REGISTERED!"
            }
    return field1




    
