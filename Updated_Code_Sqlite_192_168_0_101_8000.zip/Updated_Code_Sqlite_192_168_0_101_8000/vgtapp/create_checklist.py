'''--- Creating checkList in the DB, collection named: check_list, 15.11.2023 (modified one) ------'''
import pymongo
from datetime import datetime
import models as mdls
from vgtapp.models import check_list

# myclient = pymongo.MongoClient("mongodb://localhost:27017/")
# mydb = myclient["Guard_Patrol"]
mycol = check_list

def create_check_list(data):
   
    s_n = data["Site_Name"]
    r_n = data["Route_Name"]
    c_n = data["Camera_Name"]
    type_question = data["Question_Type"]
    add_q  = data["Add_check_query"]
    admin_id = data["Admin_UserID"]
    
    info = {
        "Site_Name":  s_n,
        "Route_Name": r_n, 
        "Camera_Name": c_n,
        "Add_check_query": add_q,
        "Admin_UserID" : admin_id,
        "Type":type_question, #To understand the type of question from the user.
        "DateOfCameraRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p"),
        "DateofCameraRegistration_DateFormat": (datetime.today()).strftime("%d/%m/%Y")
    }

    # mycol.insert_one(info)
    
    mycol.objects.create(
        Site_Name = info["Site_Name"] ,
        Route_Name = info["Route_Name"] ,
        Camera_Name = info["Camera_Name"] ,
        Add_check_query = info["Add_check_query"] ,
        Admin_UserID = info["Admin_UserID"] ,
        Type = info["Type"],
        DateOfCameraRegistration = info["DateOfCameraRegistration"],
        DateofCameraRegistration_DateFormat = info["DateofCameraRegistration_DateFormat"] 
    )
    # print('First record as Checklist Added in the DB')
    field2 = {
            "statusCode": 200,
            "statusMessage": "Query ADDED!!"
            }
    return field2

    # db_count = mycol.count_documents({})
    # if db_count == 0:

    #     info = {
    #         "Site_Name":  s_n,
    #         "Route_Name": r_n, 
    #         "Camera_Name": c_n,
    #         "Add_check_query": add_q,
    #         "Type":type_question, #To understand the type of question from the user.
    #         "DateOfCameraRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p")
    #     }

    #     mycol.insert_one(info)
    #     print('First record as Checklist Added in the DB')
    #     field2 = {
    #             "statusCode": 200,
    #             "statusMessage": "Query ADDED!!"
    #             }
    #     return field2
    # else:
    #     temp =[]
    #     temp_route = []
    #     temp_cam = []
    #     doc = mycol.find({})
    #     for y in doc:
    #         temp.append(y['Site_Name'])     #getting all the site_name
    #         temp_route.append(y['Route_Name'])
    #         temp_cam.append(y['Camera_Name'])
        
    #     if s_n in temp and r_n in temp_route and c_n in temp_cam:
    #         mylist = []
    #         n = []
          
            
    #         # check if site_name, route_name and camera_name is present in DB then add another query in the check list.
    #         for x in mycol.find({"Site_Name": s_n,"Route_Name": r_n,"Camera_Name": c_n,},{"_id":0, "Add_check_query":1}):
    #             mylist.append(x["Add_check_query"])
    #         #mylist.insert(0,add_q)
    #         print(mylist)
    #         n = [char for sublist in mylist for char in sublist]
    #         print(n)
         
            
    #         check_list = n + add_q
            
    #         #print(check_list)
    #         #check_list.append(add_q)        # adding the admin query to existing list.
    #         #print('Final:',check_list)
    #         #update the add_check_query field in the db
    #         update_info = {
    #                 "Add_check_query": check_list
    #             }
    #         mycol.update_one({"Site_Name": s_n,"Route_Name": r_n,"Camera_Name": c_n,}, {"$set": update_info})
    #         print('UPDATED check_list in DB!!')
    #         field = {
    #             "statusCode": 200,
    #             "statusMessage": "Query ADDED!!"
    #             }
    #         return field
    #     elif s_n in temp and r_n not in temp_route:
    #         info = {
    #                 "Site_Name":  s_n,
    #                 "Route_Name": r_n, 
    #                 "Camera_Name": c_n,
    #                 "Add_check_query": add_q,
    #                 "Type":type_question, #To understand the type of question from the user. 
    #                 "DateOfCameraRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p")
    #             }

    #         mycol.insert_one(info)
    #         field1 = {
    #                 "statusCode": 200,
    #                 "statusMessage": "Record added in DB"
    #                 }
    #         return field1
    #     elif s_n in temp and r_n in temp_route and c_n not in temp_cam:
    #         info = {
    #                 "Site_Name":  s_n,
    #                 "Route_Name": r_n, 
    #                 "Camera_Name": c_n,
    #                 "Add_check_query": add_q,
    #                 "Type":type_question, #To understand the type of question from the user.
    #                 "DateOfCameraRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p")
    #             }

    #         mycol.insert_one(info)
    #         field1 = {
    #                 "statusCode": 200,
    #                 "statusMessage": "Record added in DB"
    #                 }
    #         return field1
    #     else:                  # all new entry in DB
    #         if s_n not in temp:
    #             info1 = {
    #                 "Site_Name":  s_n,
    #                 "Route_Name": r_n, 
    #                 "Camera_Name": c_n,
    #                 "Add_check_query": add_q,
    #                 "Type":type_question, #To understand the type of question from the user.
    #                 "DateOfCameraRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p")
    #             }

    #             mycol.insert_one(info1)
    #             field1 = {
    #                 "statusCode": 200,
    #                 "statusMessage": "Record added in DB"
    #                 }
    #             return field1


    