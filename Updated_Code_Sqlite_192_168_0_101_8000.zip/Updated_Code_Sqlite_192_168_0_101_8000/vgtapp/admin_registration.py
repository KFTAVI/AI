'''---01.12.2023, code is for registering the admin people only, with a welcome mail ---'''
import pymongo
from datetime import datetime
import vgtapp.models as admin
import vgtapp.mail as wm


# myclient = pymongo.MongoClient("mongodb://localhost:27017/")
# mydb = myclient["Guard_Patrol"]
myad = admin.admin

storing_all_adminIDs = []
store_email = []
store_name = []
store_phone = []
userID = []
dt = []



'''----initializing the DB--------'''
def init_data():
    '''
    Clearing the data in the given list.
    '''
    
    mydoc = myad.objects.all()
    store_email.clear()
    store_phone.clear()
    store_name.clear()  
    for x in mydoc:
        store_email.append(x.Email)
        store_name.append(x.Name)
        store_phone.append(x.Phone)
        storing_all_adminIDs.append(x.Admin_Unique_UserID)

def registration(data):
    '''
    From the models which is in below format am utilizing it to 
    
    class admin_register(BaseModel):
    FirstName: str
    LastName: str
    # UserName: str    
    Company_Name: str    
    Department: str
    Designation: str
    Phone: int    
    Email:str    
    Location: str
    
    save the data in to the database. Getting the key work one by one and save the data in to the 
    database by performing the insert one function.  
    '''
    
    get_name = data["FirstName"] + ' ' + data["LastName"]
    # get_uname = data.UserName
    get_comp = data["Company_Name"]
    get_dpt = data["Department"]
    get_deg = data["Designation"]
    get_ph = data["Phone"]
    get_email = data["Email"]
    get_loc = data["Location"]
    recipient_email_id = get_email   # assigning the recipient email id 
    recipient_name = data["FirstName"]    # assigning the recipient name 

    # check for any record present in the db:
    
    #getting the count of documents in that admin collections.
    row_count =  len([docs for docs in myad.objects.all()])
    print("The row_count is:",row_count)
    # for docs in myad.objects.all():
    #     ("The docs are:",docs) 
    
    if row_count != 0:
        for x in myad.objects.all():
            p_no = x.Phone
            store_phone.append(p_no)
            e_mail = x.Email
            store_email.append(e_mail)
            n = x.Name
            store_name.append(n)
            UID = x.userID
            userID.append(UID)
            d_t = x.DateOfRegistration
            dt.append(d_t)
 
        user_id = int(max((userID))) + 1
        '''---Prevent duplicate entry, check on email------'''
        if get_name in store_name and (get_ph in store_phone or get_email in store_email):
            
            '''
            This checks if the name is stored in the given store name list 
            and if the phone is present in the store phone list 
            or the given email is present in the sore email list
            '''
            index = store_email.index(get_email)
            emailid = store_email[index]
            rg_dt = dt[index]
            show = {
                    "statusCode":500,
                    "message": "REGISTRATION DENIED!! USER ALREADY REGISTERED",
                    "emailid": emailid,
                    "RegisteredDate": rg_dt                
                }
            return show
        else:

            admin_ids = [dictinories.Admin_Unique_UserID for dictinories in myad.objects.all()]
            increased_admin_id = int(max(admin_ids))+1
            data = {
                "NAME": get_name,                    
                "userID": user_id,
                "COMPANY_NAME": get_comp,                
                "DEPARTMENT": get_dpt,
                "DESIGNATION": get_deg,
                "PHONE": get_ph,                
                "EMAIL": get_email,                
                "PASSWORD": 'admin@123',
                "Admin_Unique_UserID":increased_admin_id,
                "LOCATION": get_loc,
                "DateOfRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p")
                }
            
            x = myad.objects.create(
                Name = get_name,                    
                userID = user_id,
                Company_Name = get_comp,                
                Department = get_dpt,
                Designation = get_deg,
                Phone = get_ph,                
                Email = get_email,                
                PASSWORD = 'admin@123',
                Admin_Unique_UserID =increased_admin_id,
                Location = get_loc,
                DateOfRegistration = (datetime.today()).strftime("%b %d %Y, %I:%M %p")
            )
                # print(x)
            show = {
                "statusCode": 200,
                "statusMessage": "SUCCESSFULLY ADMIN REGISTERED!",
                "Admin_Unique_UserID":increased_admin_id
                }
            wm.email_alert(recipient_email_id,recipient_name)   # sending the welcome mail.
            return show
        
    else:       
        user_id_1 = 1
        new_admin_id = 1
        data = {
            "NAME": get_name,
            # "USER_NAME": get_uname,
            "userID": user_id_1,
            "COMPANY_NAME": get_comp,                
            "DEPARTMENT": get_dpt,
            "DESIGNATION": get_deg,
            "PHONE": get_ph,                
            "EMAIL": get_email,                
            "PASSWORD": 'admin@123',
            "Admin_Unique_UserID":new_admin_id,
            "LOCATION": get_loc,
            "DateOfRegistration": (datetime.today()).strftime("%b %d %Y, %I:%M %p")
                }
        
        x = myad.objects.create(          
                Name = get_name,                    
                userID = user_id_1,
                Company_Name = get_comp,                
                Department = get_dpt,
                Designation = get_deg,
                Phone = get_ph,                
                Email = get_email,                
                PASSWORD = 'admin@123',
                Admin_Unique_UserID =new_admin_id,
                Location = get_loc,
                DateOfRegistration = (datetime.today()).strftime("%b %d %Y, %I:%M %p")
            )

        # print(x)
        show = {
            "statusCode": 200,
            "statusMessage": "SUCCESSFULLY ADMIN REGISTERED!",
            "Admin_Unique_UserID":new_admin_id
            }
        wm.email_alert(recipient_email_id,recipient_name)   # sending the welcome mail.
        return show
        
