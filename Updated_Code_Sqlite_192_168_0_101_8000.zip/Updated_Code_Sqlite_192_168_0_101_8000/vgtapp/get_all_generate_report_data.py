import pymongo
from datetime import datetime,timedelta
from vgtapp.models import *
def get_countof_events():
    # Connect to MongoDB

    storage_of_userids = []
    storing_cameras_in_list = []
    count_of_answered_questions = ""
    # Collections
    user_database = user_management
    report_collection = Report_for_particular_sitename
    mapped_route_collection = Mapped_Route_Management
    answered_collection = Storing_Answers_To_Checklist

    
    for route_docs in mapped_route_collection.objects.all():
        admin_id = route_docs.Admin_UserID
        date_of_registration = route_docs.DateOfCameraRegistration_Dateformat
        site_name = route_docs.Site_Name
        Route_name = route_docs.Route_Name
        
        for dictionary in user_database.objects.filter(Admin_UserID = admin_id):
            storage_of_userids.append(dictionary.userID)
        
        # Update or insert into the report collection
        for dictionarys in mapped_route_collection.objects.filter(Admin_UserID = admin_id,Site_Name = site_name,Route_Name = Route_name,DateOfCameraRegistration_Dateformat = date_of_registration):
            
            storing_cameras_in_list.append(dictionarys.Camera_Name)
            # print('The resulted dict are:',dictionarys,storing_cameras_in_list,len(storing_cameras_in_list))
        
        # print("The list of cameras are:",storing_cameras_in_list[0],len(storing_cameras_in_list[0]))
        number_of_task_count = len(storing_cameras_in_list[0])
        

        report_docs = report_collection.objects.filter(admin_Id = admin_id,Site_Name = site_name,Route_Name = Route_name,Date_Of_CameraRegistration = date_of_registration)

        answer_list = [docs for docs in answered_collection.objects.filter(Admin_id = int(admin_id),
                                                        # "Site_Name":site_name,
                                                        Registered_Camera_Answer_Response = date_of_registration,
                                                        Route_Name = Route_name)]
        
        count_of_answered_questions = len(answer_list)
        if report_docs:        
            start_date_list = date_of_registration.split("/")
            start_day,start_month,start_year =int(start_date_list[0]),int(start_date_list[1]),int(start_date_list[2])
            
            End_Date = datetime.now().strftime("%d/%m/%Y")
            End_date_list = End_Date.split("/")
            End_day,End_month,End_year =int(End_date_list[0]),int(End_date_list[1]),int(End_date_list[2])
            
            # Define start and end dates   
            start_date = datetime(start_year, start_month, start_day)
            end_date = datetime(End_year, End_month, End_day)
            # print('The start date:',start_date,end_date)
            # Calculate the difference between end and start dates
            date_difference = end_date - start_date
            # Generate a list of dates within the range
            date_list = [(start_date + timedelta(days=x)).strftime("%d/%m/%Y") for x in range(date_difference.days + 1)]
            
            for dates in date_list:
                date_of_registration = dates
                count_of_answered_questions = [docs for docs in answered_collection.objects.filter(Admin_id = int(admin_id),
                                                                                #   "Site_Name":site_name,
                                                                                Registered_Camera_Answer_Response = date_of_registration,
                                                                                Route_Name = Route_name)]
                len_of_answers = len(count_of_answered_questions)
            report_collection.objects.filter(
                     admin_Id = admin_id, Route_Name = Route_name,Date_Of_CameraRegistration = date_of_registration).update(
                         Number_Of_Tasks = number_of_task_count,
                         Answered_Questions = len_of_answers
                     )
            storing_cameras_in_list.clear()
        else:
            # print("Number of cameras are:",route_docs["Camera_Name"],len(route_docs['Camera_Name']))
            report_collection.objects.create(
                admin_Id = admin_id,
                Site_Name = route_docs.Site_Name,
                Route_Name = route_docs.Route_Name,
                Number_Of_Tasks = len(route_docs.Camera_Name),
                Answered_Questions = count_of_answered_questions,
                Date_Of_CameraRegistration = date_of_registration
            )
    
    result_list_of_dict = []
    
    for docs in report_collection.objects.all():
        # print("The docs are:",docs)
        report_doc = {
        "admin_Id" : docs.admin_Id,
        "Site_Name" : docs.Site_Name,
        "Route_Name" : docs.Route_Name,
        "Number_Of_Tasks" : docs.Number_Of_Tasks,
        "Answered_Questions" : docs.Answered_Questions,
        "Date_Of_CameraRegistration" : docs.Date_Of_CameraRegistration
        }
        result_list_of_dict.append(report_doc)
    
    print("The count of events:",result_list_of_dict)
    return result_list_of_dict
