# import pymongo
# from vgtapp.models import *
# from datetime import datetime
# from datetime import date
# from datetime import time

# myclient = pymongo.MongoClient("mongodb://localhost:27017/")
# mydb = myclient["Guard_Patrol"]
# mycol = ["LOG_IN_OUT"]
# registration_mycol = user_management
# admin_mycol = admin

# def mark_login(Email,Password):
#     Email_list = []
#     Password_list = []
#     log_dt = date.today()
#     email = Email
#     Password = Password 
#     current_time = datetime.now()
#     current_hr = current_time.hour
#     current_min = current_time.minute
#     current_sec = current_time.second
#     Login_time = str(current_hr) + ':' + str(current_min) + ':' + str(current_sec)
    
#     registration_mydoc = registration_mycol.find({})                # getting all the records from the db
#     admin_registration_mydoc = admin_mycol.find({})
#     for x,y in zip(registration_mydoc,admin_registration_mydoc):
#         Email_list.append(x['Email'])
#         Password_list.append(x['Password']) #Need to change the keyword if 
#         Email_list.append(y['EMAIL'])
#         Password_list.append(y['PASSWORD']) #Need to change the keyword if
#     print("User password and email are:",Password,email)
#     if Password in Password_list and email in Email_list:
#         info ={
#             "EMAIL_ID": email,
#             # "USER_NAME": Password, 
#             "LOGIN_DATE": str(log_dt),
#             "LOGIN_TIME": Login_time,
#             "LOGOUT_TIME": '00:00:00',
#             "Date_of_registration":datetime.now().strftime("%d/%m/%Y, %H:%M:%S")
#         }
#         mycol.insert_one(info)
#         return {"Message": 'Successful LogIN'}
#     else:
#         return {"Message": "Invalid User_Name and Email address"}