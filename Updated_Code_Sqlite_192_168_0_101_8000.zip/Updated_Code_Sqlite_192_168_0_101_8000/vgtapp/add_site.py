'''---04.12.2023, the main aim of this code is to triger a post api for adding site.---'''
import pymongo
from datetime import datetime
from vgtapp.models import *

mycol = site_management
mycam = Camera_info

def adding_site(data):
    get_site_name = data["Site_Name"]
    get_site_code = data["Site_Code"]
    get_region = data["Region"]
    get_branch = data["Branch"]
    get_admin_id = data["Admin_id"]
    get_zone = data["zone"]
    count = []
    Tot = 0
    list_sites = []
    
    #Getting all the sites from the site_managment collection
    #appending all the sites into a list
    for sites in mycol.objects.filter(Site_Name=get_site_name):
        list_sites.append(sites)
        
    #if the length of the list is zero then insert the data
    if len(list_sites) == 0:
        '''--- getting the no of camera count from the camera db for the specific site_name'''
        for x in mycam.objects.filter(Site_Name = get_site_name):
            
            count.append(x.Site_Camera_Count)
            Tot = max(count)

        insert_info = {
            "Site_Name": get_site_name,
            "Site_Code": get_site_code,
            "Region": get_region,
            "Branch": get_branch,
            "Admin_id": get_admin_id,
            "Zone":get_zone,
            "No_Route": 0,
            "is_action": 1,
            "No_Of_Camera": Tot
        } 
        mycol.objects.create(
            Site_Name = insert_info["Site_Name"],
            Site_Code = insert_info["Site_Code"] ,
            Region = insert_info["Region"] ,
            Branch = insert_info["Branch"] ,
            Admin_id = insert_info["Admin_id"], 
            Zone = insert_info["Zone"] ,
            No_Route = insert_info["No_Route"], 
            is_action = insert_info["is_action"], 
            No_Of_Camera = insert_info["No_Of_Camera"] 
        )
        field = {
                "statusCode": 200,
                "statusMessage": "SUCCESSFULLY SITE ADDED!"
                }
        
    #else through an error message.
    else:
        field = {
        "statusCode": 500,
        "statusMessage": "SITE NAME ALREADY ADDED!"
        }
    
    return field
