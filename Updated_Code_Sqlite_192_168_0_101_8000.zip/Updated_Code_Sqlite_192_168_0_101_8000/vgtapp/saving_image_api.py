import os
import cv2
import time
from datetime import datetime
from urllib.parse import urlparse
import base64
import numpy as np
from PIL import Image
from vgtapp.models import Saving_Image_DB

#library section
mydb = Saving_Image_DB

def frame_to_base64(frame):
    print("I am inside the frame_to_base64 function!")
    from PIL import Image
    from io import BytesIO
    import base64
    #Taking a copy of the frame
    data = frame.copy()

    #Saving the array into images
    image_out = Image.fromarray(data)
    buffer = BytesIO() #Creating a buffer to save the image
    image_out.save(buffer, format="PNG") #The format of the buffer is PNG

    base64_str = base64.b64encode(buffer.getvalue()).decode("utf-8")
    #base64_image(base64_str,image_path)
    return base64_str

def base64_image(base64_string,image_path):
    print("I am inside the base64_image function!")
    import base64
    import random
    # Your base64 encoded string
    # base64_string = "iVBORw0KGg..."

    # Decode the base64 string
    decoded_string = base64.b64decode(base64_string)
    os.chdir("/var/tmp/")


    # Save the decoded string to a file
    with open(image_path, "wb") as f:

        f.write(decoded_string)

        print("I have saved the image!")
    change_colour(image_path)

def change_colour(image_path):
    '''
    Converting the image colour to bgr
    '''
    gray_image = cv2.imread(image_path)
    gray_to_bgr = cv2.cvtColor(gray_image,cv2.COLOR_BGR2RGB)
    cv2.imwrite(image_path,gray_to_bgr)
    print("Saved the image from gray to bgr!")

def transfer_file(src):
    '''
    Transfer file from source to destination folder
    '''
    import shutil
    from datetime import datetime
    
    todays_date = datetime.now().strftime("%d_%m_%Y") 
    todays_datetime = datetime.now().strftime("%d_%m_%Y_%H_%M_%S")
    dsc = f"/var/www/venv/VGT_API/"
    Dsc_file_path = f"/var/www/venv/VGT_API/"
    os.chmod(f"/var/tmp/{src}", 000)
    os.chmod(Dsc_file_path, 000)
    shutil.copy(src,dsc)
    final_file_path = f"/var/www/venv/VGT_API/{src}"
    
    return final_file_path

def capture_image(rtsp_lisk,admin_id,user_name,user_id,site_name,camera_name,Route_name):
    return_response = ''
    '''
    This function takes the rtsp link captures the image and saves the path in the database.
    '''
    try:
        cap = cv2.VideoCapture(rtsp_lisk)
        while cap.isOpened():
            res,frame = cap.read()
            if not res:
                cap = cv2.VideoCapture(rtsp_lisk)
                continue
            # frame = cv2.resize(frame,(640,320))

            date = datetime.now().strftime("%d_%m_%Y")
            datetime_now = datetime.now().strftime("%d_%m_%Y_%H_%M_%S")
            file_path = f"C:\HostingSpace\AITeamData\VGT\Images\{date}"
            os.makedirs(file_path,exist_ok=True)
            #print("The frames are:",frame)
            #cv2.imwrite(f'{datetime_now}.png',frame)
            #file_path = "/home/administrator/image"
            #os.makedirs(file_path,exist_ok=True)
            #os.chmod('/home/administrator/image/', 0o755)
            # os.chdir("/var/tmp/")
            file_path = f'{file_path}\{datetime_now}.png'
            #cv2.imwrite(image_path,frame)
            im = Image.fromarray(frame)
            
            im.save(file_path)
            change_colour(file_path)
            print("Image path:",file_path)
            #final_path = transfer_file(file_path)
            #print("The final path is:",final_path)
            # bgr_frame = cv2.cvtColor(frame,cv2.COLOR_GRAY2BGR)
            x,y,z = np.shape(frame)
            base64_string = frame_to_base64(frame=frame)
            if z >0 :
                    print("Line number 65!")
                    doc = {
                        "rtsp_link" : rtsp_lisk,
                        "admin_id" : admin_id ,
                        "user_name": user_name,
                        "user_id"  : user_id ,
                        "image_path": file_path,
                        "site_name": site_name,
                        "camera_name" : camera_name,
                        "Route_Name" : Route_name,
                        "Base64_string":base64_string,
                        "Datetime" : date
                         }
                    print("Inserted the document!")
                    # mydb.insert_one(doc)
                    image_data = mydb.objects.create(
                        rtsp_link  = doc["rtsp_link"],
                        admin_id   = doc["admin_id"], 
                        user_name  = doc["user_name"], 
                        user_id    = doc["user_id"], 
                        image_path  = doc["image_path"], 
                        site_name  = doc["site_name"],
                        camera_name   = doc["camera_name"], 
                        Route_Name   = doc["Route_Name"],
                        Base64_string  = doc["Base64_string"],
                        Datetime   = doc["Datetime"],  
                    )
                    image_data.save()
                    return_response = 200
            else:
                return_response = 500

            if cv2.waitKey(0):
                break
    except Exception as e:
        return e
    return return_response

