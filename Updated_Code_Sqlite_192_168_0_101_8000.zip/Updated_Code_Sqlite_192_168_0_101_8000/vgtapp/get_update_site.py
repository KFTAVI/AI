import pymongo
from datetime import datetime
from vgtapp.models import *
import urllib.parse

# site_registration
# get_VGT_CameraInfo


# myclient = pymongo.MongoClient("mongodb://localhost:27017/")
# mydb = myclient["Guard_Patrol"]
site_col = site_management
mycam = Camera_info



def site_management_camera_update():
    '''--getting specific data from the fields, site-management DB'''
    site_name = []
    camera_site_name = []
    list_to_get_count_of_dict = []
    camera_list = []
    
    '''
    logic :- Get the site names from both the collection (Site management) and (Camera_info)
    We need to check if the site name which is present in the site management is present 
    in camera info and update those site name collections in the camera_info only.
    
    Make all the site_name camera's as zero because if there is no camera registered for that
    site name in the camera info then the camera count should be zero.
    
    if different then update the count with respect to the camera info collection.
    
    '''
    
    for dict_doc in site_management.objects.all():
        site_name.append(dict_doc.Site_Name)        
    
    for mycam_dict in Camera_info.objects.all():
        camera_site_name.append(mycam_dict.Site_Name)  
    
    for sites in site_name:
        if sites in camera_site_name:
            for site_dic in Camera_info.objects.filter(Site_Name = sites):
                list_to_get_count_of_dict.append(site_dic)
            
            site_management.objects.filter(Site_Name = sites).update(No_Of_Camera=len(list_to_get_count_of_dict))
            list_to_get_count_of_dict = []
            
        else:
            site_management.objects.filter(Site_Name = sites).update(No_Of_Camera=0)

